package com.castres.breand.block6.p1.androidproject.NavigationDrawer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.castres.breand.block6.p1.androidproject.R

class AppointmentsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appointments)
    }
}