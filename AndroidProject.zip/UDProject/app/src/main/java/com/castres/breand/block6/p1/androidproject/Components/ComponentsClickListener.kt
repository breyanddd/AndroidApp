package com.castres.breand.block6.p1.androidproject.Components

interface ComponentsClickListener{
    fun onClick (componentsItems: ComponentsItems)
}