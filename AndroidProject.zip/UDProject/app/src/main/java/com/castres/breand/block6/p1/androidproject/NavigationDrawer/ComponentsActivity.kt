package com.castres.breand.block6.p1.androidproject.NavigationDrawer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import com.castres.breand.block6.p1.androidproject.Components.COMPONENTS_ID_EXTRA
import com.castres.breand.block6.p1.androidproject.Components.ComponentsCardAdapter
import com.castres.breand.block6.p1.androidproject.Components.ComponentsClickListener
import com.castres.breand.block6.p1.androidproject.Components.ComponentsDetailActivity
import com.castres.breand.block6.p1.androidproject.Components.ComponentsItems
import com.castres.breand.block6.p1.androidproject.Components.componentsList
import com.castres.breand.block6.p1.androidproject.R
import com.castres.breand.block6.p1.androidproject.databinding.ActivityComponentsBinding

class ComponentsActivity : AppCompatActivity(), ComponentsClickListener {
    private lateinit var binding: ActivityComponentsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityComponentsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        populateComponents()

        val componentsActivity = this
        binding.componentsRV.apply {
            layoutManager = GridLayoutManager(applicationContext, 3)
            adapter = ComponentsCardAdapter(componentsList, componentsActivity)
        }
    }
    override fun onClick(componentsItems: ComponentsItems) {
        val intent = Intent(applicationContext, ComponentsDetailActivity::class.java)
        intent.putExtra(COMPONENTS_ID_EXTRA,componentsItems.id)
        startActivity(intent)
    }

    private fun populateComponents() {
        val components1 = ComponentsItems(
            R.drawable.rtx4090,
            "Item1",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components1)

        val components2 = ComponentsItems(
            R.drawable.acer_nitro,
            "Item2",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components2)

        val components3 = ComponentsItems(
            R.drawable.i9,
            "Item3",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components3)

        val components4 = ComponentsItems(
            R.drawable.ramm,
            "Item4",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components4)

        val components5 = ComponentsItems(
            R.drawable.rtx4090,
            "Item5",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components5)

        val components6 = ComponentsItems(
            R.drawable.acer_nitro,
            "Item6",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components6)

        val components7 = ComponentsItems(
            R.drawable.i9,
            "Item7",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components7)

        val components8 = ComponentsItems(
            R.drawable.ramm,
            "Item8",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components8)

        val components9 = ComponentsItems(
            R.drawable.rtx4090,
            "Item9",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components9)

        val components10 = ComponentsItems(
            R.drawable.acer_nitro,
            "Item10",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components10)

        val components11 = ComponentsItems(
            R.drawable.i9,
            "Item11",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components11)

        val components12 = ComponentsItems(
            R.drawable.ramm,
            "Item12",
            "1,000",
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n",
            R.drawable.add_cart
        )
        componentsList.add(components12)
    }

}