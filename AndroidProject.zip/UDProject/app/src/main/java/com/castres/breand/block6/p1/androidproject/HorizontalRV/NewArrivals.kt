package com.castres.breand.block6.p1.androidproject.HorizontalRV

data class NewArrivals(val naImage:Int, val naName:String)
