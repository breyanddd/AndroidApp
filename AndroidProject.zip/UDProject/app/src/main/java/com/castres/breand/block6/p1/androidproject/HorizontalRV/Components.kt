package com.castres.breand.block6.p1.androidproject.HorizontalRV

data class Components(val componentsImage:Int, val componentsName:String)
