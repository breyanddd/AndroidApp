package com.castres.breand.block6.p1.androidproject.HorizontalRV

data class Partnerships(val psImage:Int, val psName:String)
